#!/bin/bash

zip -r "rpa_jerri_desktop_teste_001.zip" * -x "rpa_jerri_desktop_teste_001.zip"